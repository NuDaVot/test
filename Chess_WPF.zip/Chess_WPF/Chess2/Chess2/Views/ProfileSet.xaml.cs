﻿namespace Chess2.Views
{
    /// <summary>
    /// Логика взаимодействия для Profile.xaml
    /// </summary>
    public partial class ProfileSet : Page
    {
        public ProfileSet()
        {
            InitializeComponent();
        }
    }
}
