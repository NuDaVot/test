﻿namespace Chess2.Views
{
    /// <summary>
    /// Логика взаимодействия для Leaderboard.xaml
    /// </summary>
    public partial class Leaderboard : Page
    {
        public Leaderboard()
        {
            InitializeComponent();
        }
    }
}
