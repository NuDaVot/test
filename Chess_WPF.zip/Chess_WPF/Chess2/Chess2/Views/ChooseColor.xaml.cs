﻿namespace Chess2.Views
{
    /// <summary>
    /// Логика взаимодействия для ChooseColor.xaml
    /// </summary>
    public partial class ChooseColor : Page
    {
        public ChooseColor()
        {
            InitializeComponent();
        }
    }
}
