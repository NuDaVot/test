﻿namespace Chess2.Views
{
    /// <summary>
    /// Логика взаимодействия для MenuA_.xaml
    /// </summary>
    public partial class MenuA : Page
    {
        public MenuA()
        {
            InitializeComponent();
        }
    }
}
