﻿namespace Chess2.Views
{
    /// <summary>
    /// Логика взаимодействия для HeadsOrTails.xaml
    /// </summary>
    public partial class HeadsOrTails : Page
    {
        public HeadsOrTails()
        {
            InitializeComponent();
        }
    }
}
